-- ================================================================
-- BOUND BY INK — Complete Database Schema
-- Run this entire file in Supabase SQL Editor (Dashboard → SQL Editor)
-- ================================================================

-- Enable UUID extension
create extension if not exists "uuid-ossp";
create extension if not exists "pgcrypto";

-- ── ENUMS ──────────────────────────────────────────────────────
create type user_role                  as enum ('client', 'artist');
create type verification_status        as enum ('unverified', 'pending', 'verified', 'gold', 'platinum');
create type booking_status             as enum ('pending', 'confirmed', 'deposit_paid', 'completed', 'cancelled');
create type booking_type               as enum ('consultation', 'session');
create type design_verification_status as enum ('pending', 'approved', 'changes_requested');

-- ── PROFILES ───────────────────────────────────────────────────
-- One row per user, linked to auth.users
create table profiles (
  id           uuid        primary key references auth.users(id) on delete cascade,
  role         user_role   not null,
  full_name    text        not null,
  username     text        not null unique,
  avatar_url   text,
  bio          text,
  location     text,
  push_token   text,                       -- Expo push token for notifications
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

-- ── ARTIST PROFILES ────────────────────────────────────────────
create table artist_profiles (
  id                  uuid           primary key default uuid_generate_v4(),
  profile_id          uuid           not null unique references profiles(id) on delete cascade,
  studio_name         text,
  studio_address      text,
  specialities        text[]         not null default '{}',
  styles              text[]         not null default '{}',
  verification_status verification_status not null default 'unverified',
  insurance_active    boolean        not null default false,
  academy_level       integer        not null default 0,
  years_experience    integer,
  hourly_rate         numeric(10,2),
  deposit_amount      numeric(10,2)  not null default 25,
  follower_count      integer        not null default 0,
  rating              numeric(3,2)   not null default 0,
  review_count        integer        not null default 0,
  created_at          timestamptz    not null default now(),
  updated_at          timestamptz    not null default now()
);

-- ── PORTFOLIO ITEMS ────────────────────────────────────────────
create table portfolio_items (
  id                uuid        primary key default uuid_generate_v4(),
  artist_profile_id uuid        not null references artist_profiles(id) on delete cascade,
  image_url         text        not null,
  style_tags        text[]      not null default '{}',
  placement         text,
  description       text,
  save_count        integer     not null default 0,
  created_at        timestamptz not null default now()
);

-- ── SAVED DESIGNS ──────────────────────────────────────────────
create table saved_designs (
  id                uuid        primary key default uuid_generate_v4(),
  user_id           uuid        not null references profiles(id) on delete cascade,
  portfolio_item_id uuid        not null references portfolio_items(id) on delete cascade,
  board_name        text,
  created_at        timestamptz not null default now(),
  unique(user_id, portfolio_item_id)
);

-- ── BOOKINGS ───────────────────────────────────────────────────
create table bookings (
  id                       uuid           primary key default uuid_generate_v4(),
  client_id                uuid           not null references profiles(id) on delete restrict,
  artist_profile_id        uuid           not null references artist_profiles(id) on delete restrict,
  booking_type             booking_type   not null default 'consultation',
  status                   booking_status not null default 'pending',
  scheduled_at             timestamptz    not null,
  duration_minutes         integer        not null default 30,
  placement                text,
  size_description         text,
  style_notes              text,
  deposit_amount           numeric(10,2)  not null default 25,
  deposit_paid             boolean        not null default false,
  stripe_payment_intent_id text,
  created_at               timestamptz    not null default now(),
  updated_at               timestamptz    not null default now()
);

-- ── CONVERSATIONS ──────────────────────────────────────────────
create table conversations (
  id          uuid        primary key default uuid_generate_v4(),
  booking_id  uuid        references bookings(id) on delete set null,
  client_id   uuid        not null references profiles(id) on delete cascade,
  artist_id   uuid        not null references profiles(id) on delete cascade,
  created_at  timestamptz not null default now(),
  unique(client_id, artist_id)
);

-- ── MESSAGES ───────────────────────────────────────────────────
create table messages (
  id                         uuid                       primary key default uuid_generate_v4(),
  conversation_id            uuid                       not null references conversations(id) on delete cascade,
  sender_id                  uuid                       not null references profiles(id) on delete cascade,
  content                    text,
  design_url                 text,
  design_verification_status design_verification_status,
  design_verified_at         timestamptz,
  created_at                 timestamptz                not null default now(),
  check (content is not null or design_url is not null)
);

-- ── ACADEMY PROGRESS ───────────────────────────────────────────
create table academy_progress (
  id                uuid        primary key default uuid_generate_v4(),
  artist_profile_id uuid        not null references artist_profiles(id) on delete cascade,
  course_id         text        not null,
  completed         boolean     not null default false,
  progress_pct      integer     not null default 0 check (progress_pct between 0 and 100),
  completed_at      timestamptz,
  created_at        timestamptz not null default now(),
  unique(artist_profile_id, course_id)
);

-- ── REVIEWS ────────────────────────────────────────────────────
create table reviews (
  id                uuid        primary key default uuid_generate_v4(),
  booking_id        uuid        not null unique references bookings(id) on delete cascade,
  client_id         uuid        not null references profiles(id) on delete cascade,
  artist_profile_id uuid        not null references artist_profiles(id) on delete cascade,
  rating            integer     not null check (rating between 1 and 5),
  body              text,
  created_at        timestamptz not null default now()
);

-- ── FEED VIEW ──────────────────────────────────────────────────
-- Denormalised view used by the client discovery feed
create view feed_items as
  select
    pi.id,
    pi.artist_profile_id,
    pi.image_url,
    pi.style_tags,
    pi.placement,
    pi.save_count,
    p.full_name            as artist_name,
    p.username             as artist_username,
    p.avatar_url           as artist_avatar_url,
    ap.verification_status,
    ap.studio_address,
    ap.rating,
    pi.created_at
  from portfolio_items pi
  join artist_profiles ap on ap.id = pi.artist_profile_id
  join profiles p         on p.id  = ap.profile_id
  order by pi.created_at desc;

-- ── BOOKING SUMMARY VIEW ───────────────────────────────────────
create view booking_summary as
  select
    b.*,
    cp.full_name     as client_name,
    cp.username      as client_username,
    cp.avatar_url    as client_avatar_url,
    ap.studio_address,
    p2.full_name     as artist_name,
    p2.username      as artist_username
  from bookings b
  join profiles cp          on cp.id = b.client_id
  join artist_profiles ap   on ap.id = b.artist_profile_id
  join profiles p2          on p2.id = ap.profile_id;

-- ── TRIGGERS: updated_at ───────────────────────────────────────
create or replace function set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger profiles_updated_at
  before update on profiles
  for each row execute function set_updated_at();

create trigger artist_profiles_updated_at
  before update on artist_profiles
  for each row execute function set_updated_at();

create trigger bookings_updated_at
  before update on bookings
  for each row execute function set_updated_at();

-- ── TRIGGER: save_count ────────────────────────────────────────
create or replace function update_save_count()
returns trigger language plpgsql as $$
begin
  if TG_OP = 'INSERT' then
    update portfolio_items set save_count = save_count + 1 where id = new.portfolio_item_id;
  elsif TG_OP = 'DELETE' then
    update portfolio_items set save_count = greatest(save_count - 1, 0) where id = old.portfolio_item_id;
  end if;
  return null;
end;
$$;

create trigger saved_designs_save_count
  after insert or delete on saved_designs
  for each row execute function update_save_count();

-- ── TRIGGER: update artist rating on new review ────────────────
create or replace function update_artist_rating()
returns trigger language plpgsql as $$
begin
  update artist_profiles
  set
    rating       = (select round(avg(rating)::numeric, 2) from reviews where artist_profile_id = new.artist_profile_id),
    review_count = (select count(*) from reviews where artist_profile_id = new.artist_profile_id)
  where id = new.artist_profile_id;
  return new;
end;
$$;

create trigger reviews_update_artist_rating
  after insert on reviews
  for each row execute function update_artist_rating();

-- ── TRIGGER: auto-create profile on signup ─────────────────────
-- This fires after a user signs up via Supabase Auth
-- The user's full_name and role come from auth metadata set during signup
create or replace function handle_new_user()
returns trigger language plpgsql security definer as $$
declare
  v_role      user_role;
  v_full_name text;
  v_username  text;
begin
  v_role      := coalesce((new.raw_user_meta_data->>'role')::user_role, 'client');
  v_full_name := coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1));
  v_username  := lower(regexp_replace(v_full_name, '\s+', '_', 'g')) || '_' || substring(new.id::text, 1, 6);

  insert into profiles (id, role, full_name, username)
  values (new.id, v_role, v_full_name, v_username)
  on conflict (id) do nothing;

  -- If artist, also create artist_profiles row
  if v_role = 'artist' then
    insert into artist_profiles (profile_id)
    values (new.id)
    on conflict (profile_id) do nothing;
  end if;

  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function handle_new_user();

-- ── ROW LEVEL SECURITY ─────────────────────────────────────────

alter table profiles           enable row level security;
alter table artist_profiles    enable row level security;
alter table portfolio_items    enable row level security;
alter table saved_designs      enable row level security;
alter table bookings           enable row level security;
alter table conversations      enable row level security;
alter table messages           enable row level security;
alter table academy_progress   enable row level security;
alter table reviews            enable row level security;

-- profiles
create policy "profiles: anyone can read"  on profiles for select using (true);
create policy "profiles: owner can insert" on profiles for insert with check (auth.uid() = id);
create policy "profiles: owner can update" on profiles for update using (auth.uid() = id);

-- artist_profiles
create policy "artist_profiles: anyone can read"  on artist_profiles for select using (true);
create policy "artist_profiles: artist can insert" on artist_profiles for insert
  with check (profile_id = auth.uid());
create policy "artist_profiles: artist can update" on artist_profiles for update
  using (profile_id = auth.uid());

-- portfolio_items
create policy "portfolio: anyone can read"   on portfolio_items for select using (true);
create policy "portfolio: artist can insert" on portfolio_items for insert
  with check (artist_profile_id in (select id from artist_profiles where profile_id = auth.uid()));
create policy "portfolio: artist can update" on portfolio_items for update
  using (artist_profile_id in (select id from artist_profiles where profile_id = auth.uid()));
create policy "portfolio: artist can delete" on portfolio_items for delete
  using (artist_profile_id in (select id from artist_profiles where profile_id = auth.uid()));

-- saved_designs
create policy "saved: owner can read"   on saved_designs for select using (user_id = auth.uid());
create policy "saved: owner can insert" on saved_designs for insert with check (user_id = auth.uid());
create policy "saved: owner can delete" on saved_designs for delete using (user_id = auth.uid());

-- bookings
create policy "bookings: participant can read" on bookings for select
  using (client_id = auth.uid() or artist_profile_id in (select id from artist_profiles where profile_id = auth.uid()));
create policy "bookings: client can create" on bookings for insert
  with check (client_id = auth.uid());
create policy "bookings: participant can update" on bookings for update
  using (client_id = auth.uid() or artist_profile_id in (select id from artist_profiles where profile_id = auth.uid()));

-- conversations
create policy "conversations: participant can read" on conversations for select
  using (client_id = auth.uid() or artist_id = auth.uid());
create policy "conversations: participant can create" on conversations for insert
  with check (client_id = auth.uid() or artist_id = auth.uid());

-- messages
create policy "messages: participant can read" on messages for select
  using (conversation_id in (select id from conversations where client_id = auth.uid() or artist_id = auth.uid()));
create policy "messages: sender can insert" on messages for insert
  with check (sender_id = auth.uid() and
    conversation_id in (select id from conversations where client_id = auth.uid() or artist_id = auth.uid()));
create policy "messages: artist can update verification" on messages for update
  using (conversation_id in (select id from conversations where artist_id = auth.uid()));

-- academy_progress
create policy "academy: artist can read own" on academy_progress for select
  using (artist_profile_id in (select id from artist_profiles where profile_id = auth.uid()));
create policy "academy: artist can insert" on academy_progress for insert
  with check (artist_profile_id in (select id from artist_profiles where profile_id = auth.uid()));
create policy "academy: artist can update" on academy_progress for update
  using (artist_profile_id in (select id from artist_profiles where profile_id = auth.uid()));

-- reviews
create policy "reviews: anyone can read"  on reviews for select using (true);
create policy "reviews: client can insert" on reviews for insert with check (client_id = auth.uid());

-- ── STORAGE BUCKETS ────────────────────────────────────────────
-- Run if these don't already exist from the UI setup:

insert into storage.buckets (id, name, public) values ('portfolio', 'portfolio', true) on conflict do nothing;
insert into storage.buckets (id, name, public) values ('designs',   'designs',   true) on conflict do nothing;
insert into storage.buckets (id, name, public) values ('avatars',   'avatars',   true) on conflict do nothing;

-- Storage RLS
create policy "portfolio: public read"    on storage.objects for select using (bucket_id = 'portfolio');
create policy "portfolio: auth upload"    on storage.objects for insert
  with check (bucket_id = 'portfolio' and auth.role() = 'authenticated');
create policy "portfolio: owner delete"   on storage.objects for delete
  using (bucket_id = 'portfolio' and auth.uid()::text = (storage.foldername(name))[1]);

create policy "designs: public read"      on storage.objects for select using (bucket_id = 'designs');
create policy "designs: auth upload"      on storage.objects for insert
  with check (bucket_id = 'designs' and auth.role() = 'authenticated');

create policy "avatars: public read"      on storage.objects for select using (bucket_id = 'avatars');
create policy "avatars: auth upload"      on storage.objects for insert
  with check (bucket_id = 'avatars' and auth.role() = 'authenticated');
create policy "avatars: owner update"     on storage.objects for update
  using (bucket_id = 'avatars' and auth.uid()::text = (storage.foldername(name))[1]);
