# Bound By Ink — Quick Start Checklist

Work through this top to bottom. Each item links to the relevant section in the full setup guide.

---

## Before you start
- [ ] Node.js 18+ installed (`node --version`)
- [ ] Expo CLI installed (`npm install -g expo-cli`)
- [ ] Expo Go app on your phone
- [ ] Project unzipped and `npm install` run

---

## Supabase (Section 3)
- [ ] Account created at supabase.com
- [ ] New project created — name: `bound-by-ink`
- [ ] Project URL copied to `.env` as `EXPO_PUBLIC_SUPABASE_URL`
- [ ] Anon key copied to `.env` as `EXPO_PUBLIC_SUPABASE_ANON_KEY`
- [ ] SQL migration run (paste `001_complete_schema.sql` into SQL Editor → Run)
- [ ] Storage buckets created: `portfolio`, `designs`, `avatars` (all Public)
- [ ] Realtime enabled for `messages` table (Database → Replication)

---

## Authentication (Section 3.5)
- [ ] Email auth — enabled by default, no action needed
- [ ] Google OAuth — Client ID + Secret added to Supabase Auth → Providers → Google
- [ ] Facebook OAuth — App ID + Secret added to Supabase Auth → Providers → Facebook
- [ ] Apple Sign In — added if targeting iOS (requires paid Apple Dev account)

---

## Stripe (Section 4)
- [ ] Stripe account created at stripe.com
- [ ] Publishable key added to `.env` as `EXPO_PUBLIC_STRIPE_PUBLISHABLE_KEY`
- [ ] Supabase CLI installed (`npm install -g supabase`)
- [ ] Edge Function deployed: `supabase functions deploy create-payment-intent`
- [ ] Stripe secret key set: `supabase secrets set STRIPE_SECRET_KEY=sk_test_...`

---

## Push Notifications (Section 9)
- [ ] Notification Edge Function deployed: `supabase functions deploy send-notification`
- [ ] Service role key set: `supabase secrets set SUPABASE_SERVICE_ROLE_KEY=...`
- [ ] Tested on a physical device (notifications don't work in simulators)

---

## Running the app
- [ ] `.env` file created (copy from `.env.template`, fill in all values)
- [ ] `npm start` running
- [ ] App loaded on phone via Expo Go QR code
- [ ] Client test account created
- [ ] Artist test account created
- [ ] Full booking flow tested with Stripe test card `4242 4242 4242 4242`
- [ ] Design drop and approve/reject tested in chat

---

## Test card for Stripe
```
Card number:  4242 4242 4242 4242
Expiry:       Any future date (e.g. 12/26)
CVC:          Any 3 digits (e.g. 123)
Name:         Any name
```

---

## Common fixes
| Problem | Fix |
|---------|-----|
| `supabaseUrl is required` | Check `.env` key names start with `EXPO_PUBLIC_` |
| White screen | `npm start -- --clear` |
| Can't connect from phone | Press `S` in terminal for tunnel mode |
| Images not uploading | Confirm Storage buckets exist and are set to Public |
| Chat not realtime | Enable replication on `messages` table in Supabase |
| Stripe fails | Redeploy Edge Function, confirm secret key is set |
