// supabase/functions/send-notification/index.ts
//
// Called internally by other Edge Functions or database webhooks.
// Sends a push notification to a user via Expo Push API.
//
// Deploy:
//   supabase functions deploy send-notification --project-ref <your-ref>

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const EXPO_PUSH_URL = 'https://exp.host/--/api/v2/push/send'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface NotificationPayload {
  userId: string       // The profile ID of the recipient
  title: string
  body: string
  data?: Record<string, unknown>
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!  // service role to read any user's token
    )

    const payload: NotificationPayload = await req.json()

    // Look up the user's push token
    const { data: profile, error } = await supabase
      .from('profiles')
      .select('push_token')
      .eq('id', payload.userId)
      .single()

    if (error || !profile?.push_token) {
      return new Response(JSON.stringify({ skipped: 'no push token' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    // Send via Expo Push API
    const response = await fetch(EXPO_PUSH_URL, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        to: profile.push_token,
        title: payload.title,
        body: payload.body,
        data: payload.data ?? {},
        sound: 'default',
        badge: 1,
      }),
    })

    const result = await response.json()

    return new Response(JSON.stringify({ ok: true, result }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })

  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }
})

// ── USAGE EXAMPLES ────────────────────────────────────────────────────
//
// New message → notify other participant:
// fetch('/functions/v1/send-notification', {
//   method: 'POST',
//   headers: { Authorization: `Bearer ${serviceKey}` },
//   body: JSON.stringify({
//     userId: recipientId,
//     title: 'New message from Marco',
//     body: 'Love this direction! Totally achievable...',
//     data: { screen: 'chat', conversationId: 'xxx' },
//   }),
// })
//
// Booking confirmed → notify client:
// {
//   userId: clientId,
//   title: 'Booking confirmed ✓',
//   body: `Your consultation with Marco is confirmed for 28 March at 15:00`,
//   data: { screen: 'booking', bookingId: 'xxx' },
// }
//
// Design approved → notify client:
// {
//   userId: clientId,
//   title: 'Design approved ✓',
//   body: 'Marco has approved your stencil — see you on Friday!',
//   data: { screen: 'chat', conversationId: 'xxx' },
// }
